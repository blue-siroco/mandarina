# `@lucia/info`

> TODO: description

## Usage

```
const info = require('@lucia/info');

// TODO: DEMONSTRATE API
```
