# `@lucia/core-scales`

[![tested with jest](https://img.shields.io/badge/tested_with-jest-99424f.svg)](https://github.com/facebook/jest)

lucia calculate scales module, creates a new scale function.

## Installation

```
npm install --save @lucia/core-scales
```

## Usage ES6 Modules

There are three types of scales available. Linear, Band and Timer.

### Linear

```
import { linear } from '@lucia/core-scales';

const linearParams = {
    domain: [0, 10],
    range: [0, 300]
}

const xLinearScale = linear(linearParams);

console.info(xLinearScale(3));  // 90

```

### Band

```
import { band } from '@lucia/core-scales';

const bandParams = {
    domain:  ['One', 'Two', 'Three'],
    range: [0, 300]
}

const xBand = band(bandParams);

console.info(xBand('Two'));  // 100

```

### Timer

```
import { timer } from '@lucia/core-scales';

const timerParams = {
    domain: [new Date('2020/09/01'), new Date('2020/09/30')],
    range: [0, 300]
}

const xTimeScale = timer(timerParams);

console.info(xTimeScale('2020/09/15'));  // 140

```

## Parameters

-   `args` **[Object]** argument object.
    -   `args.orientation` **(String)** Orientation of the scale. Possible values horizontal or vertical. (optional, default `horizontal`)
    -   `args.domain` **[Number | String]** Domain of scale.
    -   `args.range` **[Number]** Range of scale
    -   `args.maxValue` **Number** Will be generated a domain from 0 to introduced value (optional, required if it not pass domain array)
    -   `args.lengthAxis` **Number** Will be generated a range from 0 to introduced value (optional, required if it not pass range array)
