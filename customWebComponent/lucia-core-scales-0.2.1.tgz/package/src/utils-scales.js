/**
 * Check received data.
 * @param {*} data
 *
 */
function checkDataParam(data) {
    // Check if data have value and is array of numbers
    if (!data || !Array.isArray(data))
        throw new Error('Data must be array of numbers');

    // If array check all elements are numbers
    if (Array.isArray(data)) {
        data.forEach((element) => {
            if (!Array.isArray(element) && isNaN(element))
                throw new Error('Data must be array of numbers');
        });
    }
}

/**
 * Round Values
 * @param {number} value
 *
 * @return {number} Round the value up to the higher pair
 */
function roundValue(value) {
    const textValue = Math.abs(value).toString();
    let returnRoundValue = 0;
    if (textValue.length === 2) {
        returnRoundValue = Number(`${Number(textValue[0]) + 1}0`);
    } else {
        returnRoundValue = (Number(textValue[0]) + 1) % 2 === 0
            ? Number(
                `${Number(textValue[0]) + 1}${'0'.repeat(
                    textValue.length - 1
                )}`
            )
            : Number(
                `${Number(textValue[0]) + 2}${'0'.repeat(
                    textValue.length - 1
                )}`
            );
    }

    return value >= 0 ? returnRoundValue : -returnRoundValue;
}

/**
 * Calculate max value of value of array or arrays of numbers
 * @param {Array} data
 *
 * @return {number} Return max round value
 */
const maxValue = (data) => {
    checkDataParam(data);
    if (Array.isArray(data[0])) {
        const maxValuesArrays = data.map((element) => {
            const arrayOfValues = element.map(row => row.value);
            return Math.max(...arrayOfValues);
        })
        return roundValue(Math.max(...maxValuesArrays));
    } else {
        return roundValue(Math.max(...data));
    }
};


/**
 * Calculate min value of value of array or arrays of numbers
 * @param {Array} data
 *
 * @return {number} Return min round value
 */
const minValue = (data) => {
    checkDataParam(data);
    if (Array.isArray(data[0])) {
        const minValuesArrays = data.map((element) => {
            const arrayOfValues = element.map(row => row.value);
            return Math.min(...arrayOfValues);
        })
        return roundValue(Math.min(...minValuesArrays));
    } else {
        return roundValue(Math.min(...data));
    }
};

export { maxValue, minValue };
