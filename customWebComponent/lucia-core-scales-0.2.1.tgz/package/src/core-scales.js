import { scaleLinear, scaleBand, scaleTime } from 'd3-scale';

/**
 * Check values and prepare it for create the scales
 * @param {object} params
 * @param {string} orientation. Orientation of scale. Possible values horizontal or vertical
 * @param {array} domain. Domain of scale
 * @param {array} range. Range of scale
 * @param {number} maxValue. If not pass domain, pass max value and generate domain from minValue to maxValue.
 * @param {number} minValue. If not pass domain, pass min value and generate domain from minValue to maxValue.
 * @param {number} lengthAxis. If not pass range, pass axis length and generate range from 0 to axis length
 * @param {number} padding. Padding between bars, default value 0.2
 *
 * @return {object}
 * @return {Array} domain. Domain of scale
 * @return {Array} range. Range of scale
 * @return {number} padding. Padding value
 */
const CheckAndPrepareValues = (params) => {
    let { orientation, domain, range, maxValue, minValue, lengthAxis, padding } = {
        ...params,
    };

    // Load default values
    if (!params.hasOwnProperty('orientation')) orientation = 'horizontal';
    if (!params.hasOwnProperty('minValue')) minValue = 0;

    // Prepare data
    domain = maxValue ? [minValue > 0 ? 0 : minValue, maxValue] : domain;
    range = lengthAxis ? [0, lengthAxis] : range;
    range = orientation === 'horizontal' ? range : range.reverse();

    // Check params
    // Check if orientation is horizontal or vertical
    if (orientation !== 'horizontal' && orientation !== 'vertical')
        throw new Error('Orientation must be horizontal or vertical');

    // Check domain & range
    if (!domain || !range) throw new Error('Must exits domain and range');

    return { domain, range, padding };
};

/**
 * Create linear scale function to draw axis
 * @param {object} params
 * @param {string} orientation. Orientation of scale. Possible values horizontal or vertical
 * @param {array} domain. Domain of scale
 * @param {array} range. Range of scale
 * @param {number} maxValue. If not pass domain, pass max value and generate domain from 0 to maxValue.
 * @param {number} lengthAxis. If not pass range, pass axis length and generate range from 0 to axis length
 *
 * @return {function} Linear scale to draw axis
 */
const linear = (params) => {
    let { domain, range } = {
        ...CheckAndPrepareValues(params),
    };
    return scaleLinear().domain(domain).range(range).nice().clamp(true);
};

/**
 * Create band scale function to draw band axis
 * @param {object} params
 * @param {string} orientation. Orientation of scale. Possible values horizontal or vertical
 * @param {array} domain. Domain of scale
 * @param {array} range. Range of scale
 * @param {number} maxValue. If not pass domain, pass max value and generate domain from 0 to maxValue.
 * @param {number} lengthAxis. If not pass range, pass axis length and generate range from 0 to axis length
 * @param {number} padding. Padding between bars, default value 0.2
 *
 * @return {function} Band scale to draw axis
 */
const band = (params) => {
    let { domain, range, padding } = {
        ...CheckAndPrepareValues(params),
    };
    return scaleBand()
        .domain(domain)
        .range(range)
        .paddingInner(padding === undefined ? 0.2 : padding)
        .paddingOuter(padding === undefined ? 0.1 : padding/2)
        // .padding(padding === undefined ? 0.2 : padding);
};

/**
 * Create time scale function to draw band axis
 * @param {object} params
 * @param {string} orientation. Orientation of scale. Possible values horizontal or vertical
 * @param {array} domain. Domain of scale
 * @param {array} range. Range of scale
 * @param {number} maxValue. If not pass domain, pass max value and generate domain from 0 to maxValue.
 * @param {number} lengthAxis. If not pass range, pass axis length and generate range from 0 to axis length
 *
 * @return {function} Time scale to draw axis
 */
const time = (params) => {
    let { domain, range } = {
        ...CheckAndPrepareValues(params),
    };
    return scaleTime().domain(domain).range(range).nice();
};

export { linear, band, time };
