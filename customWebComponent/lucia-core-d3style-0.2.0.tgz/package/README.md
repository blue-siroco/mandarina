# `@lucia/core-d3style`

> TODO: description

## Usage

```
const coreD3Style = require('@lucia/core-d3style');

// TODO: DEMONSTRATE API
```
