# `@lucia/core-d3element`

[![tested with jest](https://img.shields.io/badge/tested_with-jest-99424f.svg)](https://github.com/facebook/jest)

Create D3 object inside html element

## Installation

```
npm install --save @lucia/core-d3element
```

## Usage ES6 Modules

```
import { coreD3Element } from '@lucia/core-d3Element';
const d3GraphComponent = coreD3Element(htmlElement, heightElement, widthElement);
```
