export { GenRandomNumber } from './utils';
