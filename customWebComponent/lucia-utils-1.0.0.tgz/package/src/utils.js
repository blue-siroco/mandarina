/**
 * Create random hexadecimal number.
 * @return {string} Randamo hexadecimal number
 */
const GenRandomNumber = () => {
    const array = new Uint32Array(1);
    // `self` only exists in browsers/workers; it breaks under SSR/prerender
    // in Node. `globalThis.crypto` resolves the same Web Crypto API in both.
    return globalThis.crypto.getRandomValues(array)[0]
}


export { GenRandomNumber }