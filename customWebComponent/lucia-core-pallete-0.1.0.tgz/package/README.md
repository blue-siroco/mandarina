# `@lucia/core-pallete`

> TODO: description

## Usage

```
const corePallete = require('@lucia/core-pallete');

// TODO: DEMONSTRATE API
```
